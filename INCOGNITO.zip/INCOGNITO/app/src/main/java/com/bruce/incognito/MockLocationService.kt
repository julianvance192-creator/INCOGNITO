package com.bruce.incognito

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Criteria
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import kotlin.random.Random

class MockLocationService : Service() {

    companion object {
        @Volatile
        var running = false
        const val EXTRA_LAT = "lat"
        const val EXTRA_LON = "lon"
        private const val CHANNEL_ID = "incognito_channel"
        private const val NOTIF_ID = 1
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var lm: LocationManager
    private val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
    private var lat = 0.0
    private var lon = 0.0
    private var providersReady = false

    private val ticker = object : Runnable {
        override fun run() {
            if (!push()) {
                stopSelf()
                return
            }
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        lat = intent.getDoubleExtra(EXTRA_LAT, 0.0)
        lon = intent.getDoubleExtra(EXTRA_LON, 0.0)

        startAsForeground()

        lm = getSystemService(LOCATION_SERVICE) as LocationManager
        if (!providersReady) {
            providersReady = setupProviders()
        }
        if (!providersReady) {
            stopSelf()
            return START_NOT_STICKY
        }

        running = true
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "INCOGNITO", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("INCOGNITO is active")
            .setContentText("Your fake location is being shared")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    private fun setupProviders(): Boolean {
        return try {
            for (p in providers) {
                try {
                    lm.removeTestProvider(p)
                } catch (_: Exception) {
                }
                lm.addTestProvider(
                    p, false, false, false, false,
                    true, true, true,
                    Criteria.POWER_LOW, Criteria.ACCURACY_FINE
                )
                lm.setTestProviderEnabled(p, true)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun push(): Boolean {
        return try {
            // tiny random wobble (~1 metre) so it looks like a real GPS signal
            val jitterLat = (Random.nextDouble() - 0.5) * 0.00002
            val jitterLon = (Random.nextDouble() - 0.5) * 0.00002
            for (p in providers) {
                val loc = Location(p).apply {
                    latitude = lat + jitterLat
                    longitude = lon + jitterLon
                    altitude = 10.0
                    accuracy = 5f
                    speed = 0f
                    bearing = 0f
                    time = System.currentTimeMillis()
                    elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos()
                }
                lm.setTestProviderLocation(p, loc)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        if (::lm.isInitialized) {
            for (p in providers) {
                try {
                    lm.setTestProviderEnabled(p, false)
                    lm.removeTestProvider(p)
                } catch (_: Exception) {
                }
            }
        }
        running = false
        providersReady = false
        super.onDestroy()
    }
}
