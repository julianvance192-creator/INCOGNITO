package com.bruce.incognito

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.location.Criteria
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import java.io.File
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var map: MapView
    private lateinit var status: TextView
    private lateinit var button: Button
    private var marker: Marker? = null
    private var picked: GeoPoint? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("incognito", MODE_PRIVATE)

        Configuration.getInstance().apply {
            load(applicationContext, prefs)
            userAgentValue = packageName
            osmdroidBasePath = File(cacheDir, "osmdroid")
            osmdroidTileCache = File(cacheDir, "osmdroid/tiles")
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        val title = TextView(this).apply {
            text = "INCOGNITO"
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#111827"))
            setPadding(dp(16), dp(36), dp(16), dp(12))
        }
        root.addView(title, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#111827"))
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        root.addView(status, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        map = MapView(this).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            controller.setZoom(4.0)
            controller.setCenter(GeoPoint(20.0, 0.0))
        }
        root.addView(map, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        button = Button(this).apply {
            textSize = 16f
            setOnClickListener { toggle() }
        }
        root.addView(button, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        setContentView(root)

        map.overlays.add(MapEventsOverlay(object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                pick(p)
                return true
            }

            override fun longPressHelper(p: GeoPoint): Boolean = false
        }))

        // restore the last chosen location
        val savedLat = prefs.getString("lat", null)?.toDoubleOrNull()
        val savedLon = prefs.getString("lon", null)?.toDoubleOrNull()
        if (savedLat != null && savedLon != null) {
            val p = GeoPoint(savedLat, savedLon)
            pick(p, save = false)
            map.controller.setZoom(12.0)
            map.controller.setCenter(p)
        }

        requestNeededPermissions()
        refresh()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun pick(p: GeoPoint, save: Boolean = true) {
        picked = p
        marker?.let { map.overlays.remove(it) }
        marker = Marker(map).apply {
            position = p
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            title = "Fake location"
        }
        map.overlays.add(marker)
        map.invalidate()
        if (save) {
            prefs.edit()
                .putString("lat", p.latitude.toString())
                .putString("lon", p.longitude.toString())
                .apply()
        }
        // if already running, move the fake location right away
        if (MockLocationService.running) startMock(p)
        refresh()
    }

    private fun toggle() {
        if (MockLocationService.running) {
            stopService(Intent(this, MockLocationService::class.java))
            Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 400)
            return
        }
        val p = picked
        if (p == null) {
            Toast.makeText(this, "Tap the map to choose a location first", Toast.LENGTH_LONG).show()
            return
        }
        if (!hasPermissions()) {
            requestNeededPermissions()
            Toast.makeText(this, "Allow the permissions, then tap Start again", Toast.LENGTH_LONG).show()
            return
        }
        if (!canMock()) {
            showSetupDialog()
            return
        }
        startMock(p)
        Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 400)
    }

    private fun startMock(p: GeoPoint) {
        val i = Intent(this, MockLocationService::class.java).apply {
            putExtra(MockLocationService.EXTRA_LAT, p.latitude)
            putExtra(MockLocationService.EXTRA_LON, p.longitude)
        }
        startForegroundService(i)
    }

    private fun hasPermissions(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun requestNeededPermissions() {
        val list = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = list.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1)
    }

    /** Android only allows adding a test provider if INCOGNITO is set as the mock location app. */
    private fun canMock(): Boolean {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        return try {
            lm.addTestProvider(
                "incognito_check", false, false, false, false,
                true, true, true, Criteria.POWER_LOW, Criteria.ACCURACY_FINE
            )
            lm.removeTestProvider("incognito_check")
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun showSetupDialog() {
        AlertDialog.Builder(this)
            .setTitle("One-time setup")
            .setMessage(
                "1. Go to Settings > About phone and tap 'Build number' 7 times to turn on Developer options.\n\n" +
                "2. Open Developer options, find 'Select mock location app' and choose INCOGNITO.\n\n" +
                "3. Come back here and tap Start again."
            )
            .setPositiveButton("Open Developer options") { _, _ ->
                try {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
                } catch (e: Exception) {
                    Toast.makeText(this, "Open Settings > Developer options manually", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun refresh() {
        val p = picked
        val where = if (p == null) "Tap the map to choose your fake location."
        else String.format(Locale.US, "Fake location: %.5f, %.5f", p.latitude, p.longitude)
        if (MockLocationService.running) {
            status.text = "ACTIVE - " + where
            button.text = "STOP"
        } else {
            status.text = where
            button.text = "START"
        }
    }

    override fun onResume() {
        super.onResume()
        map.onResume()
        refresh()
    }

    override fun onPause() {
        map.onPause()
        super.onPause()
    }
}
